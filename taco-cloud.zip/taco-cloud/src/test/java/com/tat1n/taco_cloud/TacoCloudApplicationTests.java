package com.tat1n.taco_cloud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TacoCloudApplicationTests {

	@Test
	void contextLoads() {
	}

}
